﻿using EFDatabaseOne.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EFDatabaseOne
{
    public partial class Form1 : Form
    {
        //globls 
        Student st = new Student();
        DatabaseContext databasecontext = new DatabaseContext();
        int id = 0;

        public Form1()
        {
            InitializeComponent();
            bindgridview();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void bindgridview ()
        {
            dataGridView1.DataSource = databasecontext.Students.ToList<Student>();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //insert btn get values
            st.Name= TBname.Text;   
            st.Gender= comboBox1.SelectedItem.ToString();   
            st.Age = Convert.ToInt32(TBage.Text);   
            st.Campus= TBcampus.Text;
            //pass on to the db 
            databasecontext.Students.Add(st);
            //to save changess 
            int a = databasecontext.SaveChanges();

            //handeling
            if (a > 0) 
            {
                MessageBox.Show("entery added to database ");
                bindgridview();
                ClearAll();
            }
            else
            {
                MessageBox.Show("failed to insert data ");
            }
        }

        //clear all the textboxes and combobox
        public void ClearAll()
        {
            //clear all
            TBname.Clear();
            TBcampus.Clear();
            TBage.Clear();
            comboBox1.SelectedItem = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //update btn
            // get values from design view 
            st.ID = id;
            st.Name = TBname.Text;
            st.Gender = comboBox1.SelectedItem.ToString();
            st.Age= Convert.ToInt32(TBage.Text);
            st.Campus = TBcampus.Text;
            //pass it to to an update statment 
            databasecontext.Entry(st).State = System.Data.Entity.EntityState.Modified;
            //save the change 
            int a = databasecontext.SaveChanges();
            //if else to handel faill 
            if (a > 0)
            {
                MessageBox.Show("data updated");
                //see change call bindgridview
                bindgridview();
            } 
            else
            {
                MessageBox.Show("data update failed");
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //read back from database on double click 
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            //if the item exists read back
            st = databasecontext.Students.Where(x => x.ID == id).FirstOrDefault();
            //place it into the design object 
            TBname.Text = st.Name;
            comboBox1.SelectedItem= st.Gender;
            TBage.Text = st.Age.ToString();
            TBcampus.Text = st.Campus;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Btndelet_Click(object sender, EventArgs e)
        {
            //delete button clicks
            //check permissions first
            DialogResult result = MessageBox.Show("Are you sure you want to delete this entry?", "Permissions", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //if they chose yes or no
            if (result == DialogResult.Yes)
            {
                st = databasecontext.Students.Where(x => x.ID == id).FirstOrDefault();
                databasecontext.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                int a = databasecontext.SaveChanges();

                //handle failing option
                if (a > 0)
                {
                    MessageBox.Show("Entry deleted");
                    bindgridview();
                    ClearAll();
                }
                else
                {
                    MessageBox.Show("Failed to delete item");
                }
            }
            else
            {
                MessageBox.Show("You cancelled deleting the data");
            }
        }

        private void Btncancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
