﻿namespace Shop_inventory.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MySpace : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Inventories",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Product = c.String(),
                        Catagory = c.String(),
                        Description = c.String(),
                        Quantity = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Inventories");
        }
    }
}
