﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using Shop_inventory.Model;

namespace Shop_inventory
{
    public partial class Form1 : Form
    {
        Inventory iv = new Inventory();
        DatabaseContext databasecontext = new DatabaseContext();
        int id = 0;


        public void ClearAll()
        {
            TBProduct.Clear();
            TBCatagory.Clear();
            TBDescription.Clear();
            TBQuantity.Clear();
        }

        public void bindgridview()
        {
            dataGridView1.DataSource = databasecontext.Inventory.ToList<Inventory>();
        }


        public Form1()
        {
            InitializeComponent();
            bindgridview();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BTNInsert_Click(object sender, EventArgs e)
        {
            iv.Product = TBProduct.Text;
            iv.Catagory = TBCatagory.Text;
            iv.Description = TBDescription.Text;
            iv.Quantity = Convert.ToInt32(TBQuantity.Text);

            databasecontext.Inventory.Add(iv);

            int a = databasecontext.SaveChanges();

            if (a > 0)
            {
                MessageBox.Show("entery added to database ");
                bindgridview();
                ClearAll();
            }
            else
            {
                MessageBox.Show("failed to insert data ");
            }
        }

        private void BTNDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete this entry?", "Permissions", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                iv = databasecontext.Inventory.Where(x => x.ID == id).FirstOrDefault();
                databasecontext.Entry(iv).State = System.Data.Entity.EntityState.Deleted;
                int a = databasecontext.SaveChanges();

                if (a > 0)
                {
                    MessageBox.Show("Entry deleted");
                    bindgridview();
                    ClearAll();
                }
                else
                {
                    MessageBox.Show("Failed to delete item");
                }
            }
            else
            {
                MessageBox.Show("You cancelled deleting the data");
            }
        }

        private void BTNUpdate_Click(object sender, EventArgs e)
        {
            iv.ID = id;
            iv.Product = TBProduct.Text;
            iv.Catagory = TBCatagory.Text;
            iv.Description = TBDescription.Text;
            iv.Quantity = Convert.ToInt32(TBQuantity.Text);

            databasecontext.Entry(iv).State = System.Data.Entity.EntityState.Modified;

            int a = databasecontext.SaveChanges();

            if (a > 0)
            {
                MessageBox.Show("data updated");

                bindgridview();
                ClearAll();
            }
            else
            {
                MessageBox.Show("data update failed");
            }
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

            iv = databasecontext.Inventory.Where(x => x.ID == id).FirstOrDefault();

            TBProduct.Text = iv.Product;
            TBCatagory.Text = iv.Catagory;
            TBDescription.Text = iv.Description;
            TBQuantity.Text = iv.Quantity.ToString();
        }
    }
}
